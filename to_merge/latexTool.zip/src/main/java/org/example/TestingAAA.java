package org.example;

public class TestingAAA {
    public void testing() {

        MatrixLatex m = new MatrixLatex(4,4);
        ComboLatex c = new ComboLatex(new Latex("\\sum_{i=1}^k"),
                new DiffLatex("f_1","g_i",DiffLatex.PARTIAL)
                ,new DiffLatex("g_i","x_1",DiffLatex.PARTIAL));
        m.addElement(new MatrixElementLatex(1,1,c));
        c = new ComboLatex(new Latex("\\sum_{i=1}^k"),
                new DiffLatex("f_1","g_i",DiffLatex.PARTIAL)
                ,new DiffLatex("g_i","x_2",DiffLatex.PARTIAL));
        m.addElement(new MatrixElementLatex(1,2,c));
        m.addElement(new MatrixElementLatex(1,3,new Latex(MatrixLatex.C_DOTS)));
        c = new ComboLatex(new Latex("\\sum_{i=1}^k"),
                new DiffLatex("f_1","g_i",DiffLatex.PARTIAL)
                ,new DiffLatex("g_i","x_2",DiffLatex.PARTIAL));
        m.addElement(new MatrixElementLatex(1,4,c));


        c = new ComboLatex(new Latex("\\sum_{i=1}^k"),
                new DiffLatex("f_2","g_i",DiffLatex.PARTIAL)
                ,new DiffLatex("g_i","x_1",DiffLatex.PARTIAL));
        m.addElement(new MatrixElementLatex(2,1,c));
        c = new ComboLatex(new Latex("\\sum_{i=1}^k"),
                new DiffLatex("f_2","g_i",DiffLatex.PARTIAL)
                ,new DiffLatex("g_i","x_2",DiffLatex.PARTIAL));
        m.addElement(new MatrixElementLatex(2,2,c));
        m.addElement(new MatrixElementLatex(2,3,new Latex(MatrixLatex.C_DOTS)));
        c = new ComboLatex(new Latex("\\sum_{i=1}^k"),
                new DiffLatex("f_2","g_i",DiffLatex.PARTIAL)
                ,new DiffLatex("g_i","x_2",DiffLatex.PARTIAL));
        m.addElement(new MatrixElementLatex(2,4,c));

        m.addElement(new MatrixElementLatex(3,1,new Latex(MatrixLatex.C_DOTS)));
        m.addElement(new MatrixElementLatex(3,2,new Latex(MatrixLatex.C_DOTS)));
        m.addElement(new MatrixElementLatex(3,3,new Latex(MatrixLatex.C_DOTS)));
        m.addElement(new MatrixElementLatex(3,4,new Latex(MatrixLatex.C_DOTS)));

        c = new ComboLatex(new Latex("\\sum_{i=1}^k"),
                new DiffLatex("f_m","g_i",DiffLatex.PARTIAL)
                ,new DiffLatex("g_i","x_1",DiffLatex.PARTIAL));
        m.addElement(new MatrixElementLatex(4,1,c));
        c = new ComboLatex(new Latex("\\sum_{i=1}^k"),
                new DiffLatex("f_m","g_i",DiffLatex.PARTIAL)
                ,new DiffLatex("g_i","x_2",DiffLatex.PARTIAL));
        m.addElement(new MatrixElementLatex(4,2,c));
        m.addElement(new MatrixElementLatex(4,3,new Latex(MatrixLatex.C_DOTS)));
        c = new ComboLatex(new Latex("\\sum_{i=1}^k"),
                new DiffLatex("f_m","g_i",DiffLatex.PARTIAL)
                ,new DiffLatex("g_i","x_2",DiffLatex.PARTIAL));
        m.addElement(new MatrixElementLatex(4,4,c));
        System.out.println(m.getLatexString());
    }

}
