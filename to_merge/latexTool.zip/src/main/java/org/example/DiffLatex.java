package org.example;

public class DiffLatex extends Latex {
    public static final String FULL = "D";
    public static final String PARTIAL = "P";


    protected Latex nominator;
    protected Latex denominator;
    protected String type;
    public DiffLatex(String nominator, String denominator , String type ) {
        super();
        this.nominator = new Latex(nominator);
        this.denominator = new Latex(denominator);
        this.type = type;
    }

    @Override
    protected String getLatex() {
        StringBuilder sb = new StringBuilder();
        //\dfrac{\partial \mathbf{f}(\mathbf{x})}{\partial x_{1}}
        sb.append("\\dfrac");

        if (FULL.equals(type)) {
            sb.append("{d ");
            sb.append(nominator.getLatex());
            sb.append("}{");
            sb.append("{d ");
            sb.append(denominator.getLatex());
            sb.append("}");
        } else {
            sb.append("{\\partial ");
            sb.append(nominator.getLatex());
            sb.append("}");
            sb.append("{\\partial ");
            sb.append(denominator.getLatex());
            sb.append("}");
        }
        return sb.toString();
    }
}
