package org.example;

import java.time.LocalDateTime;

/**
 * Hello world!
 *
 */
public class App {
    public static void main(String[] args) {

        System.out.println("Hello World!");
        testCode();


    }

    public static void testCode() {
        //System.out.println(new DiffLatex(new Latex("x"),
         //       new Latex("t"),
         //       DiffLatex.DF_TYPE_PARTIAL)
          //      .getLatex());
        MatrixLatex m = new MatrixLatex(3,4);
        m.addElement(new MatrixElementLatex(1,1,new DiffLatex("f_1","x_1",DiffLatex.PARTIAL)));
        m.addElement(new MatrixElementLatex(1,2,new DiffLatex("f_1","x_2",DiffLatex.PARTIAL)));
        m.addElement(new MatrixElementLatex(1,3,new Latex(MatrixLatex.C_DOTS)));
        m.addElement(new MatrixElementLatex(1,4,new DiffLatex("f_1","x_n",DiffLatex.PARTIAL)));


        m.addElement(new MatrixElementLatex(2,1,new Latex(MatrixLatex.C_DOTS)));
        m.addElement(new MatrixElementLatex(2,2,new Latex(MatrixLatex.C_DOTS)));
        m.addElement(new MatrixElementLatex(2,3,new Latex(MatrixLatex.C_DOTS)));
        m.addElement(new MatrixElementLatex(2,4,new Latex(MatrixLatex.C_DOTS)));

        m.addElement(new MatrixElementLatex(3,1,new DiffLatex("f_m","x_1",DiffLatex.PARTIAL)));
        m.addElement(new MatrixElementLatex(3,2,new DiffLatex("f_m","x_2",DiffLatex.PARTIAL)));
        m.addElement(new MatrixElementLatex(3,3,new Latex(MatrixLatex.C_DOTS)));
        m.addElement(new MatrixElementLatex(3,4,new DiffLatex("f_m","x_n",DiffLatex.PARTIAL)));

        System.out.println(m.getLatexString());


    }
}
