package org.example;

public class Latex {


    protected String latex;

    public Latex() {
    }

    public Latex(Latex latex) {
        this.latex = latex.getLatex();
    }

    public Latex(String latex) {
        this.latex = latex;
    }

    protected String getLatex() {
        System.out.println("Base class getLatex");

        return latex;
    }

}
