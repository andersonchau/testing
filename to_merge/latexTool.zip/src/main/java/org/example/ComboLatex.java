package org.example;

import java.sql.Array;
import java.util.ArrayList;
import java.util.List;

public class ComboLatex extends Latex {
    List<Latex> latexes;

    public ComboLatex(Latex... latexes) {
        super("");
        this.latexes = new ArrayList<Latex>();
        for (int i = 0; i < latexes.length; i++) {
            this.latexes.add(new Latex(latexes[i].getLatex()));
        }
    }

    @Override
    public String getLatex() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < latexes.size() ; i++) {
            if ( i > 0 ) sb.append(" ");
            sb.append(latexes.get(i).getLatex());
        }
        return sb.toString();
    }


}
