package org.example;
import java.util.ArrayList;
import java.util.List;

public class MatrixLatex {
    protected List<MatrixElementLatex> elementList;
    protected Integer row;
    protected Integer col;

    public static final String C_DOTS = "\\cdots";
    public static final String V_DOTS = "\\vdots";
    public static final String D_DOTS = "\\ddots";

    public MatrixLatex(Integer row, Integer col) {
        elementList = new ArrayList<>();
        this.row = row;
        this.col = col;
    }

    public MatrixLatex addElement(MatrixElementLatex e) {
        elementList.add(e);
        return this;
    }

    public String getElementLatexByRolCol(Integer row, Integer col){
        for( MatrixElementLatex mle : elementList ) {
            if ( mle.getCol().equals(col) && mle.getRow().equals(row) ) {
                return mle.getLatex();
            }
        }
        return "NF";
    }


    public String getLatexString() {
        StringBuilder sb = new StringBuilder();
        //sb.append("\\left[\\begin{array}{");
        //for( int i = 0 ; i < col ; i++ ) sb.append("c");
        //sb.append("} \n");
        sb.append("\\begin{bmatrix}\n");
        for( int r = 1; r <= row ; r++ ){
            for( int c = 1 ; c <= col ; c++ ) {
                if ( c == 1 ) {
                    sb.append(" ");
                } else {
                    sb.append(" & ");
                }
                sb.append( getElementLatexByRolCol(r,c));
                if ( c == col ) {
                    if ( r == row ) {
                        sb.append("\n");
                    } else {
                        sb.append(" \\\\ \n");
                    }
                }
            }

        }
        //sb.append("\\end{array}\\right] ");
        sb.append("\\end{bmatrix}");
        return sb.toString();
    }

    public List<MatrixElementLatex> getElementList() {
        return elementList;
    }

    public void setElementList(List<MatrixElementLatex> elementList) {
        this.elementList = elementList;
    }

    public Integer getRow() {
        return row;
    }

    public void setRow(Integer row) {
        this.row = row;
    }

    public Integer getCol() {
        return col;
    }

    public void setCol(Integer col) {
        this.col = col;
    }
    /*
     /*
    \left[\begin{array}{ccc}
\dfrac{\partial \mathbf{f}(\mathbf{x})}{\partial x_{1}} & \cdots & \dfrac{\partial \mathbf{f}(\mathbf{x})}{\partial x_{n}}
\end{array}\right]

     */


}
